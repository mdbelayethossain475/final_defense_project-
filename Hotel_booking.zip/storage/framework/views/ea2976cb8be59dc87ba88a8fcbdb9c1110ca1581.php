
<?php $__env->startSection('content'); ?>
    <div class="container card">
        <div class="col-sm-6 p-md-2">
            <div class="welcome-text">
                <h4>Update Staff</h4>

            </div>

        </div>

        <div class="card">
            <form action="<?php echo e(url('update_staff/'.$data->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Full Name</h4>
                    </div>
                    <input value="<?php echo e($data->full_name); ?>" name="full_name" type="text" class="form-control" id="example name">
                </div>
                <br>

                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Mobile</h4>
                    </div>
                    <input value="<?php echo e($data->mobile); ?>" name="mobile" type="text" class="form-control" id="example name">
                </div>
                <br>
                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Choose department</h4>
                    </div>
                    <div class="form-group">
                        <select name="department_id" class="form-control">
                            <option value="<?php echo e($data->department_id); ?>" default><?php echo e($data->department->title); ?></option>
                           
                            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <br>
                <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Biodata</h4>
                    </div>
                    <input value="<?php echo e($data->bio); ?>" name="bio" type="text" class="form-control" id="example name">
                </div>
                <br>

                <?php $__errorArgs = ['salary_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Salary Type</h4>
                    </div>
                    <div class="container">
                        <div class="row">
                           <?php if($data->salary_type =='Weekly'): ?>
                           <div class="col-2"> <input checked name="salary_type" type="radio" value="Weekly" > <span>Weekly</span></div>
                           <div class="col-2">  <input name="salary_type" type="radio" value="Monthly" ><span>Monthly</span></div>
                           <?php else: ?>
                           <div class="col-2"> <input  name="salary_type" type="radio" value="Weekly" > <span>Weekly</span></div>
                           <div class="col-2">  <input checked name="salary_type" type="radio" value="Monthly" ><span>Monthly</span></div>
                           <?php endif; ?>
                            
                        </div>
                    </div>
                   
                  
                </div>
                <br>

                <?php $__errorArgs = ['salary_amt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Salary Amount</h4>
                    </div>
                    <input value="<?php echo e($data->salary_amt); ?>" name="salary_amt" type="text" class="form-control" id="example name">
                </div>
                <br>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Photo</h4>
                    </div>
                    <img src="/storage/<?php echo e($data->photo); ?>" height="50"  alt="..."></td>
                    <input  name="photo" type="file" class="form-control" id="example name">
                </div>
                <br>

                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/edit_staff.blade.php ENDPATH**/ ?>