home
<?php /**PATH E:\Laravel\Hotel_booking\resources\views/welcome.blade.php ENDPATH**/ ?>