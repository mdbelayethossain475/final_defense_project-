
<?php $__env->startSection('content'); ?>
    <div class="container card">
        <div class="col-sm-6 p-md-2">
            <div class="welcome-text">
                <h4>Room Booking</h4>

            </div>

        </div>

        <div class="card">
              

        <div class="modal-content">
            <div class="container">
                <form action="<?php echo e(url('/room_booking')); ?>" method="post" enctype="multipart/form">
                    <?php echo csrf_field(); ?>
                   
                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3">
                        <div class="card-header">
                            <h4 class="card-title"> Select Customer </h4>
                        </div>
                        <div class="form-group">
                            <select name="customer_id" class="form-control">
                              
                                <option default>--select--</option>
                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->full_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <br>
                    
                 
                    <div class="mb-3">
                        <div class="card-header">
                            <h4 class="card-title"> Room  : <?php echo e($data->title); ?></h4>
                        </div>
                        <input name="room_id" type="hidden" value="<?php echo e($data->id); ?>" />
                    </div>
                    <br>
                    <?php $__errorArgs = ['checkin_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3">
                        <div class="card-header">
                            <h4 class="card-title"> Check in Date :<?php echo e($in); ?> </h4>
                        </div>
                        <input value="<?php echo e($in); ?>" name="checkin_date" type="hidden" class="form-control" id="example name">
                    </div>
                    <br>
                    <?php $__errorArgs = ['checkout_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3">
                        <div class="card-header">
                            <h4 class="card-title"> Check out Date:<?php echo e($out); ?> </h4>
                        </div>
                        <input value="<?php echo e($out); ?>" name="checkout_date" type="hidden" class="form-control" id="example name">
                    </div>
                    <br>
                    <?php $__errorArgs = ['total_adult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3">
                        <div class="card-header">
                            <h4 class="card-title"> Total Adult </h4>
                        </div>
                        <div class="form-group">
                            <select name="total_adult" class="form-control">
                              
                                <option default>--select--</option>
                               
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                               
                            </select>
                        </div>
                    </div>
                    <br>
                    <?php $__errorArgs = ['total_clildren'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3">
                        <div class="card-header">
                            <h4 class="card-title"> Total Children </h4>
                        </div>
                        <div class="form-group">
                            <select name="total_clildren" class="form-control">                             
                                <option default>--select--</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                    </div>
                    <br>
        
                   
        
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Confirm Booking</button>
                    </div>
                </form>
            </div>
            
            
        </div>
   
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/final_book.blade.php ENDPATH**/ ?>