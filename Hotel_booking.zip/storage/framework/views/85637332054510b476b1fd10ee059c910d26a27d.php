
<?php $__env->startSection('content'); ?>

<style>
    .body{
        color: rgb(43, 41, 41);
    }
</style>
<div class="card-body">
    <div class="table-responsive">
        <div class="welcome-text">
            <h4>Available room for  <?php echo e($start_date); ?>  To  <?php echo e($end_date); ?></h4>
        </div>
        <br>
        <table id="example" class="display" style="min-width: 845px">
            <thead>
                <tr>
                    
                    <th>Room </th>
                    <th>Price</th>                                
                    <th>Category</th>
                    <th>Action</th>
                    
                   
                    
                </tr>
            </thead>
            <tbody class="body" >
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->title); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->room_type->title); ?></td>
                      
                    
                    <td>
                       
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <a  href="<?php echo e(url('/final_booking'.'/'.$item->id.'/'.$start_date.'/'.$end_date)); ?>" type="button" class="btn btn-danger text-white ">Book Now</a>
                          </div>
                       
                    </td>
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
             
            </tbody>
            
        </table>
    </div>
</div>
  

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/room_search_table.blade.php ENDPATH**/ ?>