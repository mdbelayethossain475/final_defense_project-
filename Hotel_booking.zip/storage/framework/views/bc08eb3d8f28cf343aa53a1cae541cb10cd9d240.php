
<?php $__env->startSection('content'); ?>
<style>
    .r{
color: rgb(0, 0, 0)
    }
</style>
<div class="container">
    <div class="col-sm-6 p-md-2">
        <div class="welcome-text">
            <h3>Roomtype Details</h3>
            <hr>

        </div>

    </div>
    
    <div class="r row p-3">
        <div class="col-6">Room Type :</div>
        <div class="col-6"><?php echo e($data->title); ?></div>
        <hr>
    </div>
   
    <div class="r row p-3">
        <div class="col-6">Details :</div>
        <div class="col-6"><?php echo e($data->detail); ?></div>
        <hr>
    </div>
    
    <div class="r row p-3">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $data->roomtypeimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card p-2 col-1.5 imgcol<?php echo e($img->id); ?>" style="width: 8rem;">
                        <img src="/storage/<?php echo e($img->img_src); ?>" height="70px" alt="..."></td>
                        <div class="card-body">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a  href="<?php echo e(url('/room_type_image_delete'.'/'.$img->id)); ?>" type="button" class="btn btn-danger text-white "><i
                                    class="fa fa-trash-o" aria-hidden="true"></i></a>
                              </div>
                          
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 
    <div class="r row p-3">
        <div class="btn-group" role="group" aria-label="Basic example">
            <a href="<?php echo e(url('/edit_roomtype'.'/'.$data->id)); ?>" type="button" class="btn btn-primary text-white ">Edit</a>
          </div>
       
    </div>
   
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/view_roomtype.blade.php ENDPATH**/ ?>