
<?php $__env->startSection('content'); ?>
<style>
    .r{
color: rgb(0, 0, 0)
    }
</style>
<div class="container">
    <div class="col-sm-6 p-md-2">
        <div class="welcome-text">
            <h3>Customer Details</h3>
            <hr>

        </div>

    </div>
    
    <div class="r row p-3">
        <div class="col-6">Full Name :</div>
        <div class="col-6"><?php echo e($data->full_name); ?></div>
        <hr>
    </div>
   
    <div class="r row p-3">
        <div class="col-6">Email :</div>
        <div class="col-6"><?php echo e($data->email); ?></div>
        <hr>
    </div>
    
    <div class="r row p-3">
        <div class="col-6">Mobile</div>
        <div class="col-6"><?php echo e($data->mobile); ?></div>
        <hr>
    </div>
    
    <div class="r row p-3">
        <div class="col-6">Address</div>
        <div class="col-6"><?php echo e($data->address); ?></div>
        <hr>
    </div>

    <div class="r row p-3">
        <div class="col-6">Picture</div>
        <img src="/storage/<?php echo e($data->photo); ?>" height="50"  alt="..."></td>
        <hr>
    </div>
 
    <div class="r row p-3">
        <div class="btn-group" role="group" aria-label="Basic example">
            <a href="<?php echo e(url('/edit_customer'.'/'.$data->id)); ?>" type="button" class="btn btn-primary text-white ">Edit</a>
          </div>
       
    </div>
   
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/view_customer.blade.php ENDPATH**/ ?>