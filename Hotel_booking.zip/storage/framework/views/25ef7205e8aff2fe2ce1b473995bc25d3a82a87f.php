
<?php $__env->startSection('content'); ?>
<style>
    .r{
color: rgb(0, 0, 0)
    }
</style>
<div class="container">
    <div class="col-sm-6 p-md-2">
        <div class="welcome-text">
            <h3>Staff Details</h3>
            <hr>

        </div>

    </div>
    
    <div class="r row p-3">
        <div class="col-6">Full Name :</div>
        <div class="col-6"><?php echo e($data->full_name); ?></div>
        <hr>
    </div>
   
    <div class="r row p-3">
        <div class="col-6">Mobile :</div>
        <div class="col-6"><?php echo e($data->mobile); ?></div>
        <hr>
    </div>
    
    <div class="r row p-3">
        <div class="col-6">Department</div>
        <div class="col-6"><?php echo e($data->department->title); ?></div>
        <hr>
    </div>
    
    <div class="r row p-3">
        <div class="col-6">BioData</div>
        <div class="col-6"><?php echo e($data->bio); ?></div>
        <hr>
    </div>

    <div class="r row p-3">
        <div class="col-6">Salary Type</div>
        <div class="col-6"><?php echo e($data->salary_type); ?></div>
        <hr>
    </div>
    
    <div class="r row p-3">
        <div class="col-6">Salary Amount</div>
        <div class="col-6"><?php echo e($data->salary_amt); ?></div>
        <hr>
    </div>

    <div class="r row p-3">
        <div class="col-6">Picture</div>
        <img src="/storage/<?php echo e($data->photo); ?>" height="50"  alt="..."></td>
        <hr>
    </div>
 
    <div class="r row p-3">
        <div class="btn-group" role="group" aria-label="Basic example">
            <a href="<?php echo e(url('/edit_staff'.'/'.$data->id)); ?>" type="button" class="btn btn-primary text-white ">Edit</a>
          </div>
       
    </div>
   
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/view_staff.blade.php ENDPATH**/ ?>