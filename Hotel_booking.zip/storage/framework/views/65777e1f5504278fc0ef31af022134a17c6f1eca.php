
<?php $__env->startSection('content'); ?>
    <div class="container card">
        <div class="col-sm-6 p-md-2">
            <div class="welcome-text">
                <h4>Add Customer</h4>

            </div>

        </div>

        <div class="card">
            <form action="<?php echo e(route('insert_customer')); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Full Name</h4>
                    </div>
                    <input required name="full_name" type="text" class="form-control" id="example name">
                </div>
                <br>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Email</h4>
                    </div>
                    <input required name="email" type="email" class="form-control" id="example name">
                </div>
                <br>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Password</h4>
                    </div>
                    <input required name="password" type="password" class="form-control" id="example name">
                </div>
                <br>
                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Mobile</h4>
                    </div>
                    <input required name="mobile" type="text" class="form-control" id="example name">
                </div>
                <br>
              
                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Address</h4>
                    </div>
                    <input required name="address" type="text" class="form-control" id="example name">
                </div>
                <br>

                <div class="mb-3">
                    <div class="card-header">
                        <h4 class="card-title">Photo</h4>
                    </div>
                    <input required name="photo" type="file" class="form-control" id="example name">
                </div>
                <br>




                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\Hotel_booking\resources\views/admin/add_customer.blade.php ENDPATH**/ ?>