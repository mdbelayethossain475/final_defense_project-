(function($) {
    "use strict"



})(jQuery);